package com.poly.context;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBContext {
    
    /* SỬA MẬT KHẨU CỦA BẠN Ở ĐÂY */
    private static final String SERVER = "localhost";
    private static final String PORT = "1433";
    private static final String DB_NAME = "PolyNewsDB";
    private static final String USER = "sa";
    private static final String PASSWORD = "123456"; // <--- Sửa pass ở đây

    public Connection getConnection() throws Exception {
        // Cấu hình cho SQL Server mới (yêu cầu encrypt)
        String url = "jdbc:sqlserver://" + SERVER + ":" + PORT + ";databaseName=" + DB_NAME 
                   + ";encrypt=true;trustServerCertificate=true;";
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        return DriverManager.getConnection(url, USER, PASSWORD);
    }
    
    // Hàm main để test kết nối
    public static void main(String[] args) {
        try {
            System.out.println(new DBContext().getConnection());
            System.out.println("Kết nối thành công!");
        } catch (Exception e) {
            System.out.println("Kết nối thất bại: " + e.getMessage());
        }
    }
}