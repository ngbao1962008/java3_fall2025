package com.poly.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig; // [QUAN TRỌNG] Thêm cái này
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part; // [QUAN TRỌNG] Thêm cái này để xử lý file

import com.poly.dao.CategoryDAO;
import com.poly.dao.NewsDAO;
import com.poly.entity.News;
import com.poly.entity.User;

@MultipartConfig // [QUAN TRỌNG] Bắt buộc phải có dòng này thì mới upload được
@WebServlet({"/admin", "/admin/create", "/admin/update", "/admin/delete", "/admin/save"})
public class AdminController extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. Kiểm tra đăng nhập
        User user = (User) req.getSession().getAttribute("acc");
        
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Chặn khách hàng vào trang Admin
        if (user.getRole().equals("CUSTOMER")) {
            resp.sendRedirect(req.getContextPath() + "/home");
            return;
        }

        String path = req.getServletPath();
        NewsDAO newsDAO = new NewsDAO();
        CategoryDAO catDAO = new CategoryDAO();

        // 2. Điều hướng chức năng
        if (path.contains("create")) {
            req.setAttribute("cats", catDAO.getAll()); 
            req.getRequestDispatcher("/view/admin/news-form.jsp").forward(req, resp);
            
        } else if (path.contains("update")) {
            String id = req.getParameter("id");
            req.setAttribute("news", newsDAO.findById(id)); 
            req.setAttribute("cats", catDAO.getAll());
            req.getRequestDispatcher("/view/admin/news-form.jsp").forward(req, resp);
            
        } else if (path.contains("delete")) {
            String id = req.getParameter("id");
            newsDAO.delete(id);
            resp.sendRedirect(req.getContextPath() + "/admin"); 
            
        } else {
            // == TRANG DASHBOARD ==
            List<News> list;
            
            // Phân quyền dữ liệu
            if (user.getRole().equals("ADMIN")) { 
                list = newsDAO.getAll(); // Admin thấy hết
            } else {
                list = newsDAO.getAllByAuthor(user.getId()); // Reporter thấy tin mình
            }
            
            req.setAttribute("listNews", list);
            req.getRequestDispatcher("/view/admin/index.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("acc");
        
        // Bảo mật lớp 2 khi lưu:
        if (user == null || user.getRole().equals("CUSTOMER")) {
            resp.sendRedirect(req.getContextPath() + "/home");
            return;
        }

        req.setCharacterEncoding("UTF-8");
        NewsDAO dao = new NewsDAO();
        
        String id = req.getParameter("id");
        String title = req.getParameter("title");
        String content = req.getParameter("content");
        String categoryId = req.getParameter("categoryId");
        boolean home = req.getParameter("home") != null; 
        
        // --- XỬ LÝ UPLOAD ẢNH (Phần mới thêm) ---
        String image = req.getParameter("image"); // Lấy đường dẫn cũ (từ input hidden)
        
        try {
            // Lấy file từ form (name="imageFile")
            Part part = req.getPart("imageFile"); 
            
            // Nếu người dùng có chọn file mới
            if (part != null && part.getSize() > 0) {
                // 1. Tạo đường dẫn thực tế tới thư mục /files
                String realPath = req.getServletContext().getRealPath("/files");
                if (!Files.exists(Paths.get(realPath))) {
                    Files.createDirectories(Paths.get(realPath));
                }
                
                // 2. Lấy tên file gốc
                String filename = Paths.get(part.getSubmittedFileName()).getFileName().toString();
                
                // 3. Lưu file vào ổ cứng server
                part.write(realPath + "/" + filename);
                
                // 4. Cập nhật đường dẫn mới để lưu vào CSDL
                image = "files/" + filename;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // ----------------------------------------
        
        String author = user.getId();

        News n = new News(id, title, content, image, null, author, 0, categoryId, home);

        if (dao.findById(id) == null) {
            dao.insert(n);
        } else {
            dao.update(n);
        }
        
        resp.sendRedirect(req.getContextPath() + "/admin");
    }
}