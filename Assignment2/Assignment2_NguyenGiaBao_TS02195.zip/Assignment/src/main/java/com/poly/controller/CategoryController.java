package com.poly.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.poly.dao.CategoryDAO;
import com.poly.entity.Category;
import com.poly.entity.User;

@WebServlet({"/admin/categories", "/admin/categories/create", "/admin/categories/update", "/admin/categories/delete", "/admin/categories/save"})
public class CategoryController extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("acc");
        // Chỉ Admin mới được vào quản lý danh mục (Phóng viên không được)
        if (user == null || !user.getRole().equals("ADMIN")) {
            resp.sendRedirect(req.getContextPath() + "/home");
            return;
        }

        String path = req.getServletPath();
        CategoryDAO dao = new CategoryDAO();

        if (path.contains("create")) {
            req.getRequestDispatcher("/view/admin/category-form.jsp").forward(req, resp);
            
        } else if (path.contains("update")) {
            String id = req.getParameter("id");
            req.setAttribute("cate", dao.findById(id));
            req.getRequestDispatcher("/view/admin/category-form.jsp").forward(req, resp);
            
        } else if (path.contains("delete")) {
            String id = req.getParameter("id");
            dao.delete(id);
            resp.sendRedirect(req.getContextPath() + "/admin/categories");
            
        } else {
            // Danh sách
            req.setAttribute("listCate", dao.getAll());
            req.getRequestDispatcher("/view/admin/category-list.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        CategoryDAO dao = new CategoryDAO();
        
        String id = req.getParameter("id");
        String name = req.getParameter("name");
        Category c = new Category(id, name);

        if (dao.findById(id) == null) {
            dao.insert(c);
        } else {
            dao.update(c);
        }
        
        resp.sendRedirect(req.getContextPath() + "/admin/categories");
    }
}
