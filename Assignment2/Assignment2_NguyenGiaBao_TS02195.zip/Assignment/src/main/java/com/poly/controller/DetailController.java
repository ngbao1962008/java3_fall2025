package com.poly.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.poly.dao.NewsDAO;
import com.poly.entity.News;

@WebServlet("/detail") // Bắt đường dẫn /detail
public class DetailController extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. Lấy ID từ URL
        String id = req.getParameter("id");
        
        // 2. Gọi DAO lấy tin tức từ SQL
        NewsDAO dao = new NewsDAO();
        News news = dao.findById(id);
        
        // 3. Đẩy dữ liệu sang trang JSP hiển thị
        req.setAttribute("news", news);
        
        // 4. Chuyển hướng
        req.getRequestDispatcher("view/user/detail.jsp").forward(req, resp);
    }
}