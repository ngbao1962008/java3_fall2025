package com.poly.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.poly.dao.NewsDAO;
import com.poly.entity.News;
import com.poly.entity.User;

@WebServlet("/home")
public class HomeController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        // 1. Chặn cửa (Bắt buộc đăng nhập)
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("acc");
        if (user == null) {
            resp.sendRedirect("login");
            return;
        }

        // 2. Logic lấy dữ liệu
        NewsDAO dao = new NewsDAO();
        List<News> list;
        String titleMain; // Tiêu đề hiển thị trên web (VD: TIN NÓNG, XÃ HỘI...)

        // Lấy tham số 'cid' từ trên thanh địa chỉ (URL)
        String cid = req.getParameter("cid");

        if (cid == null || cid.isEmpty()) {
            // Nếu không chọn danh mục -> Lấy Top 5 tin nóng
            list = dao.getTop5Hot();
            titleMain = "🔥 TIN NÓNG (TOP 5)";
        } else {
            // Nếu chọn danh mục -> Lọc theo mã danh mục
            list = dao.getByCategory(cid);
            
            // Đặt tên tiêu đề cho đẹp
            switch(cid) {
                case "XH": titleMain = "🏙️ TIN XÃ HỘI"; break;
                case "TG": titleMain = "🌍 TIN THẾ GIỚI"; break;
                case "KD": titleMain = "💰 TIN KINH DOANH"; break;
                case "TT": titleMain = "⚽ TIN THỂ THAO"; break;
                default: titleMain = "📰 TIN TỨC"; break;
            }
        }
        
        // 3. Gửi dữ liệu sang JSP
        req.setAttribute("listNews", list); // Danh sách tin
        req.setAttribute("titleMain", titleMain); // Tiêu đề
        
        req.getRequestDispatcher("view/user/home_view.jsp").forward(req, resp);
    }
}