package com.poly.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.poly.dao.UserDAO;
import com.poly.entity.User;

@WebServlet("/login")
public class LoginController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("view/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String u = req.getParameter("username");
        String p = req.getParameter("password");
        
        // Gọi DAO mới (đã hỗ trợ tìm cả 2 bảng)
        User user = new UserDAO().checkLogin(u, p);

        if (user == null) {
            req.setAttribute("mess", "Sai thông tin đăng nhập!");
            req.getRequestDispatcher("view/login.jsp").forward(req, resp);
        } else {
            HttpSession session = req.getSession();
            session.setAttribute("acc", user);
            
            // Logic phân quyền mới (Dựa trên String)
            String role = user.getRole();
            
            if (role.equals("ADMIN")) {
                resp.sendRedirect("admin"); // Admin vào trang quản trị
            } 
            else if (role.equals("REPORTER")) {
                resp.sendRedirect("admin"); // Phóng viên cũng vào trang quản trị (để đăng bài)
            } 
            else {
                resp.sendRedirect("home"); // Khách hàng (CUSTOMER) về trang chủ
            }
        }
    }
}