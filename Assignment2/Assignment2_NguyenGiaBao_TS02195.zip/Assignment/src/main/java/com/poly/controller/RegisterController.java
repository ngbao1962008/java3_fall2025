package com.poly.controller;

import java.io.IOException;
import java.util.Random;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.poly.dao.UserDAO;
import com.poly.entity.User;
import com.poly.utils.EmailUtils;

@WebServlet("/register")
public class RegisterController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("view/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        
        String user = req.getParameter("username");
        String pass = req.getParameter("password");
        String re_pass = req.getParameter("repassword");
        String fullname = req.getParameter("fullname");
        String email = req.getParameter("email");

        // 1. Validate cơ bản
        if (!pass.equals(re_pass)) {
            req.setAttribute("mess", "Mật khẩu xác nhận không khớp!");
            req.getRequestDispatcher("view/register.jsp").forward(req, resp);
            return;
        } 
        
        UserDAO dao = new UserDAO();
        if (dao.checkUserExist(user) != null) {
            req.setAttribute("mess", "Tài khoản đã tồn tại!");
            req.getRequestDispatcher("view/register.jsp").forward(req, resp);
            return;
        }

        // 2. SINH MÃ CODE (6 số ngẫu nhiên)
        Random rand = new Random();
        int randomCode = rand.nextInt(900000) + 100000; // Ví dụ: 458921
        String code = String.valueOf(randomCode);

        // 3. GỬI MAIL (Chạy ngầm)
        String subject = "Mã xác thực đăng ký ABC News";
        String body = "<h3>Xin chào " + fullname + "!</h3>"
                    + "<p>Mã xác thực của bạn là: <b style='font-size:20px; color:red;'>" + code + "</b></p>"
                    + "<p>Vui lòng không chia sẻ mã này cho ai.</p>";
        
        new Thread(() -> {
            EmailUtils.send(email, subject, body);
        }).start();

        // 4. LƯU TẠM VÀO SESSION (Để sang trang kia check)
        // Tạo đối tượng User tạm (chưa lưu vào DB)
        User tempUser = new User(user, pass, fullname, email, "CUSTOMER");
        
        HttpSession session = req.getSession();
        session.setAttribute("authCode", code); // Lưu mã đúng
        session.setAttribute("tempUser", tempUser); // Lưu thông tin khách
        
        // 5. CHUYỂN HƯỚNG SANG TRANG NHẬP MÃ
        resp.sendRedirect("verify"); 
    }
}