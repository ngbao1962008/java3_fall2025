package com.poly.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.poly.dao.UserDAO;
import com.poly.entity.User;

@WebServlet({"/admin/users", "/admin/users/create", "/admin/users/update", "/admin/users/delete", "/admin/users/save"})
public class UserController extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("acc");
        
        // Chỉ Admin mới được vào
        if (user == null || !user.getRole().equals("ADMIN")) {
            resp.sendRedirect(req.getContextPath() + "/home");
            return;
        }

        String path = req.getServletPath();
        UserDAO dao = new UserDAO();

        if (path.contains("create")) {
            // == TRANG THÊM MỚI ==
            req.getRequestDispatcher("/view/admin/user-form.jsp").forward(req, resp);
            
        } else if (path.contains("update")) {
            // == TRANG SỬA ==
            String id = req.getParameter("id");
            req.setAttribute("userItem", dao.findById(id));
            req.getRequestDispatcher("/view/admin/user-form.jsp").forward(req, resp);
            
        } else if (path.contains("delete")) {
            // == XÓA USER ==
            String id = req.getParameter("id");
            dao.delete(id);
            resp.sendRedirect(req.getContextPath() + "/admin/users");
            
        } else {
            // == TRANG DANH SÁCH + BỘ LỌC (FILTER) ==
            String filter = req.getParameter("filter"); // Lấy tham số từ URL
            List<User> list;

            if ("staff".equals(filter)) {
                // Lọc Nhân viên (Admin + Reporter)
                list = dao.filterByRole(true);
            } else if ("customer".equals(filter)) {
                // Lọc Khách hàng
                list = dao.filterByRole(false);
            } else {
                // Mặc định: Lấy tất cả
                list = dao.getAll();
            }
            
            req.setAttribute("listUsers", list);
            req.setAttribute("currentFilter", filter); // Để highlight nút bấm
            req.getRequestDispatcher("/view/admin/user-list.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        UserDAO dao = new UserDAO();
        
        String id = req.getParameter("id");
        String password = req.getParameter("password");
        String fullname = req.getParameter("fullname");
        String email = req.getParameter("email");
        
        // Lấy Role từ Dropdown (ADMIN, REPORTER, CUSTOMER)
        String role = req.getParameter("role"); 

        User u = new User(id, password, fullname, email, role);

        if (dao.findById(id) == null) {
            dao.insert(u);
        } else {
            dao.update(u);
        }
        
        resp.sendRedirect(req.getContextPath() + "/admin/users");
    }
}