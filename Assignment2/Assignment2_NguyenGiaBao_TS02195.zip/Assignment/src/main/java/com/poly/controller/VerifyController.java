package com.poly.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.poly.dao.UserDAO;
import com.poly.entity.User;

@WebServlet("/verify")
public class VerifyController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Chỉ hiện trang nhập mã
        req.getRequestDispatcher("view/verify.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. Lấy mã người dùng nhập
        String inputCode = req.getParameter("inputCode");
        
        // 2. Lấy mã gốc trong Session
        HttpSession session = req.getSession();
        String authCode = (String) session.getAttribute("authCode");
        User tempUser = (User) session.getAttribute("tempUser");

        // 3. Kiểm tra
        if (inputCode != null && inputCode.equals(authCode)) {
            // === MÃ ĐÚNG: TIẾN HÀNH LƯU VÀO DATABASE ===
            UserDAO dao = new UserDAO();
            dao.signup(tempUser.getId(), tempUser.getPassword(), tempUser.getFullname(), tempUser.getEmail());
            
            // Xóa session tạm
            session.removeAttribute("authCode");
            session.removeAttribute("tempUser");
            
            req.setAttribute("mess", "Đăng ký thành công! Mời bạn đăng nhập.");
            req.getRequestDispatcher("view/login.jsp").forward(req, resp);
            
        } else {
            // === MÃ SAI ===
            req.setAttribute("mess", "Mã xác thực không đúng! Vui lòng thử lại.");
            req.getRequestDispatcher("view/verify.jsp").forward(req, resp);
        }
    }
}