package com.poly.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.poly.context.DBContext;
import com.poly.entity.Category;

public class CategoryDAO {
	// 1. Lấy tất cả
    public List<Category> getAll() {
        List<Category> list = new ArrayList<>();
        String sql = "SELECT * FROM Categories";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Category(rs.getString("Id"), rs.getString("Name")));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 2. Tìm theo ID
    public Category findById(String id) {
        String sql = "SELECT * FROM Categories WHERE Id=?";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Category(rs.getString("Id"), rs.getString("Name"));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    // 3. Thêm mới
    public void insert(Category c) {
        String sql = "INSERT INTO Categories (Id, Name) VALUES (?, ?)";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, c.getId());
            ps.setString(2, c.getName());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 4. Cập nhật
    public void update(Category c) {
        String sql = "UPDATE Categories SET Name=? WHERE Id=?";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, c.getName());
            ps.setString(2, c.getId());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 5. Xóa
    public void delete(String id) {
        // Lưu ý: Nếu loại tin này đã có bài viết, SQL sẽ báo lỗi khóa ngoại.
        // Cần xóa bài viết trước hoặc xử lý ngoại lệ (Ở mức cơ bản ta cứ xóa thôi)
        String sql = "DELETE FROM Categories WHERE Id=?";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
}