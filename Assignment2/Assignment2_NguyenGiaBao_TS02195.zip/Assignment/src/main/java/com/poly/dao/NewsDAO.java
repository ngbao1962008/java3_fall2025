package com.poly.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.poly.context.DBContext;
import com.poly.entity.News;

public class NewsDAO {

    // --- PHẦN CHO NGƯỜI DÙNG (TRANG CHỦ) ---

    // 1. Lấy Top 5 tin nóng (Home=1, sắp xếp theo ngày giảm dần)
    public List<News> getTop5Hot() {
        List<News> list = new ArrayList<>();
        String sql = "SELECT TOP 5 * FROM News WHERE Home=1 ORDER BY PostedDate DESC";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // --- PHẦN CHO ADMIN / PHÓNG VIÊN (QUẢN TRỊ) ---

    // 2. Lấy TẤT CẢ tin (Dành cho Admin)
    public List<News> getAll() {
        List<News> list = new ArrayList<>();
        String sql = "SELECT * FROM News ORDER BY PostedDate DESC";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 3. Lấy tin theo TÁC GIẢ (Dành cho Phóng viên)
    public List<News> getAllByAuthor(String authorId) {
        List<News> list = new ArrayList<>();
        String sql = "SELECT * FROM News WHERE Author = ? ORDER BY PostedDate DESC";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, authorId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 4. Tìm tin theo ID (Để hiện lên form Sửa)
    public News findById(String id) {
        String sql = "SELECT * FROM News WHERE Id=?";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    // 5. Thêm mới
    public void insert(News n) {
        String sql = "INSERT INTO News (Id, Title, Content, Image, PostedDate, Author, ViewCount, CategoryId, Home) VALUES (?, ?, ?, ?, GETDATE(), ?, 0, ?, ?)";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, n.getId());
            ps.setString(2, n.getTitle());
            ps.setString(3, n.getContent());
            ps.setString(4, n.getImage());
            ps.setString(5, n.getAuthor());
            ps.setString(6, n.getCategoryId());
            ps.setBoolean(7, n.isHome());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 6. Cập nhật
    public void update(News n) {
        String sql = "UPDATE News SET Title=?, Content=?, Image=?, CategoryId=?, Home=? WHERE Id=?";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, n.getTitle());
            ps.setString(2, n.getContent());
            ps.setString(3, n.getImage());
            ps.setString(4, n.getCategoryId());
            ps.setBoolean(5, n.isHome());
            ps.setString(6, n.getId());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 7. Xóa
    public void delete(String id) {
        String sql = "DELETE FROM News WHERE Id=?";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
    
    // Hàm phụ trợ để map dữ liệu cho gọn (Tránh code lặp lại)
    private News mapRow(ResultSet rs) throws SQLException {
        return new News(
            rs.getString("Id"), rs.getString("Title"), rs.getString("Content"),
            rs.getString("Image"), rs.getDate("PostedDate"), rs.getString("Author"),
            rs.getInt("ViewCount"), rs.getString("CategoryId"), rs.getBoolean("Home")
        );
    }
    
 // 8. Lọc tin theo Danh mục (CategoryId)
    public List<News> getByCategory(String categoryId) {
        List<News> list = new ArrayList<>();
        String sql = "SELECT * FROM News WHERE CategoryId = ? ORDER BY PostedDate DESC";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, categoryId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}