package com.poly.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.poly.context.DBContext;
import com.poly.entity.User;

public class UserDAO {

    // 1. Check Login
    public User checkLogin(String user, String pass) {
        User u = checkTable("Staffs", user, pass);
        if (u != null) return u;
        return checkTable("Customers", user, pass);
    }

    private User checkTable(String tableName, String user, String pass) {
        try (Connection conn = new DBContext().getConnection()) {
            String sql = "SELECT * FROM " + tableName + " WHERE Id=? AND Password=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, user);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new User(rs.getString("Id"), rs.getString("Password"), 
                        rs.getString("Fullname"), rs.getString("Email"), rs.getString("Role"));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }
    
    // 2. Check User Exist (HÀM BẠN ĐANG THIẾU)
    public User checkUserExist(String username) {
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps1 = conn.prepareStatement("SELECT * FROM Staffs WHERE Id=?");
            ps1.setString(1, username);
            if (ps1.executeQuery().next()) return new User();

            PreparedStatement ps2 = conn.prepareStatement("SELECT * FROM Customers WHERE Id=?");
            ps2.setString(1, username);
            if (ps2.executeQuery().next()) return new User();
        } catch (Exception e) {}
        return null;
    }

    // 3. Signup
    public void signup(String user, String pass, String fullname, String email) {
        try (Connection conn = new DBContext().getConnection()) {
            String sql = "INSERT INTO Customers (Id, Password, Fullname, Email, Role) VALUES (?, ?, ?, ?, 'CUSTOMER')";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, user);
            ps.setString(2, pass);
            ps.setString(3, fullname);
            ps.setString(4, email);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 4. GetAll
    public List<User> getAll() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT Id, Password, Fullname, Email, Role FROM Staffs UNION SELECT Id, Password, Fullname, Email, Role FROM Customers";
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new User(rs.getString("Id"), rs.getString("Password"), 
                        rs.getString("Fullname"), rs.getString("Email"), rs.getString("Role")));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 5. FindById
    public User findById(String id) {
        List<User> list = getAll();
        for (User u : list) {
            if (u.getId().equals(id)) return u;
        }
        return null;
    }

    // 6. Delete
    public void delete(String id) {
        try (Connection conn = new DBContext().getConnection()) {
            conn.prepareStatement("DELETE FROM Staffs WHERE Id='" + id + "'").executeUpdate();
            conn.prepareStatement("DELETE FROM Customers WHERE Id='" + id + "'").executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
    
    // 7. Insert
    public void insert(User u) {
        String table = "Customers";
        if (u.getRole().equals("ADMIN") || u.getRole().equals("REPORTER")) table = "Staffs";
        
        try (Connection conn = new DBContext().getConnection()) {
            String sql = "INSERT INTO " + table + " (Id, Password, Fullname, Email, Role) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, u.getId());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getFullname());
            ps.setString(4, u.getEmail());
            ps.setString(5, u.getRole());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
    
    // 8. Update
    public void update(User u) {
        delete(u.getId());
        insert(u);
    }
    
    // 9. Filter
    public List<User> filterByRole(boolean isStaff) {
        List<User> list = new ArrayList<>();
        String table = isStaff ? "Staffs" : "Customers";
        String sql = "SELECT Id, Password, Fullname, Email, Role FROM " + table;
        try (Connection conn = new DBContext().getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new User(rs.getString("Id"), rs.getString("Password"), 
                        rs.getString("Fullname"), rs.getString("Email"), rs.getString("Role")));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}