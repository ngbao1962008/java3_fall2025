package com.poly.entity;

public class Newsletter {

}
