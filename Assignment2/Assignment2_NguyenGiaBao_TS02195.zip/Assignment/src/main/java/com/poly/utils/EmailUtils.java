package com.poly.utils;

import java.util.Properties;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class EmailUtils {

    // Cấu hình email của bạn (Người gửi)
    private static final String FROM_EMAIL = "ngbao19062008@gmail.com";
    private static final String PASSWORD = "nqjg tkqr iydf hqnf";

    public static void send(String to, String subject, String body) {
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com"); // SMTP Host
        props.put("mail.smtp.port", "587"); // TLS Port
        props.put("mail.smtp.auth", "true"); // Enable Auth
        props.put("mail.smtp.starttls.enable", "true"); // Enable TLS

        // Tạo Session
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, PASSWORD);
            }
        });

        try {
            // Tạo tin nhắn
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(FROM_EMAIL, "ABC News System")); // Tên người gửi
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject, "UTF-8");
            message.setContent(body, "text/html; charset=UTF-8"); // Gửi dưới dạng HTML

            // Gửi mail
            Transport.send(message);
            System.out.println("Gửi mail thành công đến: " + to);
            
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Gửi mail thất bại!");
        }
    }
}