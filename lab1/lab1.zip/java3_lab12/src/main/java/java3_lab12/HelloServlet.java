package java3_lab12;

@WebServlet("/poly")
public class HelloServlet {

}
