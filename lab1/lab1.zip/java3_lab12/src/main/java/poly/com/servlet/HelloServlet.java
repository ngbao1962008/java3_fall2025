package poly.com.servlet;


@WebServlet("/java3_lab12/Hello.php")
public class HelloServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletResquest req, HttpServletRespone resp)
	throws ServletException, IOException {
		resp.getWriter().println("<h1>FPT Polytechnic</h1>");
	}
}
