package poly.com.Controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.model.User;

@WebServlet("/form/update")
public class FormServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User bean = new User();
        bean.setFullname("Nguyễn Gia Bảo");
        bean.setGender(true);
        bean.setCountry("VN");

        req.setAttribute("user", bean);
        req.setAttribute("editable", true);
        req.getRequestDispatcher("/form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String fullname = req.getParameter("fullname");
        System.out.println("Fullname nhập: " + fullname);

        req.getRequestDispatcher("/form.jsp").forward(req, resp);
    }
}
