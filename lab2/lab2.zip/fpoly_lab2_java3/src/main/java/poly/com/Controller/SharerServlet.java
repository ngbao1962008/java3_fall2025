package poly.com.Controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
;

@WebServlet("/sharer")
public class SharerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        req.setAttribute("title", "Demo SharerServlet");
        req.setAttribute("message", "Hello from SharerServlet");
        // forward tới page.jsp
        req.getRequestDispatcher("/page.jsp").forward(req, resp);
    }
}
