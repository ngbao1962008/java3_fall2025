package poly.com.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/lab3bai3","/lab3bai4"})
public class Lab3bai3controller extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	{
		// TODO Auto-generated method stub
		String chon=req.getRequestURI();
		if (chon.contains("/lab3bai3"))
		{
			Map<String,Object> map = new HashMap<>();
			map.put("name", "iphone 2024");
			map.put("price", 12345678);
			map.put("date", new Date());
			req.setAttribute("item", map);
			req.getRequestDispatcher("lab3bai3.jsp").forward(req, resp);
		}
		else
		{
			Map<String,Object> map = new HashMap<>();
			map.put("Title", "Tiêu đề bản tin");
			map.put("content", "Nội dung bản tin thường rất dài");
			req.setAttribute("item", map);
			req.getRequestDispatcher("lab3bai4.jsp").forward(req, resp);
		}
	}
	}
}