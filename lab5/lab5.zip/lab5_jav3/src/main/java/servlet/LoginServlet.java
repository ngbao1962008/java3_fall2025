package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.Base64;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Kiểm tra Cookie
        Cookie[] cookies = req.getCookies();
        String username = "";
        String password = "";

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("auth")) {
                    String encodedValue = cookie.getValue();
                    try {
                        byte[] decodedBytes = Base64.getDecoder().decode(encodedValue);
                        String decodedString = new String(decodedBytes);
                        // Giả sử lưu dạng: username:password
                        String[] parts = decodedString.split(":"); 
                        if (parts.length == 2) {
                            username = parts[0];
                            password = parts[1];
                        }
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        
        req.setAttribute("username", username);
        req.setAttribute("password", password);
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String u = req.getParameter("username");
        String p = req.getParameter("password");
        String remember = req.getParameter("remember");

        // Giả lập check login
        if ("admin".equals(u) && "123".equals(p)) {
            // Login thành công -> Lưu session
            HttpSession session = req.getSession();
            session.setAttribute("user", u);
            req.setAttribute("message", "Đăng nhập thành công!");

            // Xử lý Remember Me (Cookie)
            Cookie cookie;
            if (remember != null) {
                // Mã hóa thông tin trước khi lưu cookie
                String auth = u + ":" + p;
                String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
                cookie = new Cookie("auth", encodedAuth);
                cookie.setMaxAge(30 * 24 * 60 * 60); // 30 ngày
            } else {
                // Nếu không tích remember, xóa cookie cũ nếu có
                cookie = new Cookie("auth", "");
                cookie.setMaxAge(0);
            }
            cookie.setPath("/"); // Quan trọng: set path để toàn bộ app đọc được
            resp.addCookie(cookie);

        } else {
            req.setAttribute("message", "Sai tài khoản hoặc mật khẩu!");
        }
        
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }
}