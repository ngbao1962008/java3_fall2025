package servlet;

import com.poly.utils.Mailer;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/mail")
public class MailServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/mail.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String to = req.getParameter("to");
        String subject = req.getParameter("subject");
        String body = req.getParameter("body");

        try {
            Mailer.send(to, subject, body);
            req.setAttribute("message", "Gửi mail thành công!");
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("message", "Lỗi gửi mail: " + e.getMessage());
        }
        req.getRequestDispatcher("/mail.jsp").forward(req, resp);
    }
}
