package servlet;

import com.poly.bean.Staff;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.DateTimeConverter;

import java.io.IOException;
import java.util.Date;

@WebServlet("/staff")
public class StaffServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/index.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Staff bean = new Staff();
        try {
            // Định dạng ngày tháng
            DateTimeConverter dtc = new DateConverter(new Date());
            dtc.setPattern("yyyy-MM-dd"); // Format mặc định của input type="date" HTML5
            ConvertUtils.register(dtc, Date.class);

            // Đổ dữ liệu vào Bean
            BeanUtils.populate(bean, req.getParameterMap());

            // Gửi bean sang JSP để hiển thị lại
            req.setAttribute("bean", bean);
            req.setAttribute("message", "Đã đọc dữ liệu thành công: " + bean.getFullname());
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("message", "Lỗi: " + e.getMessage());
        }
        req.getRequestDispatcher("/index.jsp").forward(req, resp);
    }
}
