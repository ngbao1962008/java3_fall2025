package poly.dao;

import java.util.List;
import poly.entity.Employee;

public interface EmployeeDAO {
    List<Employee> findAll();
    Employee findById(String id);
    void create(Employee employee);
    void update(Employee employee);
    void deleteById(String id);
}

