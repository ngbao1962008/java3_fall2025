package poly.utils;

import java.sql.*;

public class Jdbc {
    static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    static String dburl = "jdbc:sqlserver://localhost;database=lab67_jav3;encrypt=false;trustServerCertificate=true";
    static String username = "sa";
    static String password = "123456";
    
    static {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            System.err.println("Warning: SQL Server JDBC Driver not found. Database operations may fail.");
            e.printStackTrace();
        }
    }
    
    /**Mở kết nối*/
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dburl, username, password);
    }
    
    /**Thao tác dữ liệu với Statement*/
    public static int executeUpdate(String sql) throws SQLException {
        Connection connection = getConnection();
        Statement statement = connection.createStatement();
        int result = statement.executeUpdate(sql);
        statement.close();
        connection.close();
        return result;
    }
    
    /**Truy vấn dữ liệu với Statement*/
    public static ResultSet executeQuery(String sql) throws SQLException {
        Connection connection = getConnection();
        Statement statement = connection.createStatement();
        return statement.executeQuery(sql);
    }
    
    /**Thao tác dữ liệu với PreparedStatement*/
    public static int executeUpdate(String sql, Object... values) throws SQLException {
        Connection connection = getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        for (int i = 0; i < values.length; i++) {
            statement.setObject(i + 1, values[i]);
        }
        int result = statement.executeUpdate();
        statement.close();
        connection.close();
        return result;
    }
    
    /**Truy vấn dữ liệu với PreparedStatement*/
    public static ResultSet executeQuery(String sql, Object... values) throws SQLException {
        Connection connection = getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        for (int i = 0; i < values.length; i++) {
            statement.setObject(i + 1, values[i]);
        }
        return statement.executeQuery();
    }
    
    /**Thao tác dữ liệu với CallableStatement*/
    public static int executeUpdateCallable(String sql, Object... values) throws SQLException {
        Connection connection = getConnection();
        CallableStatement statement = connection.prepareCall(sql);
        for (int i = 0; i < values.length; i++) {
            statement.setObject(i + 1, values[i]);
        }
        int result = statement.executeUpdate();
        statement.close();
        connection.close();
        return result;
    }
    
    /**Truy vấn dữ liệu với CallableStatement*/
    public static ResultSet executeQueryCallable(String sql, Object... values) throws SQLException {
        Connection connection = getConnection();
        CallableStatement statement = connection.prepareCall(sql);
        for (int i = 0; i < values.length; i++) {
            statement.setObject(i + 1, values[i]);
        }
        return statement.executeQuery();
    }
}

